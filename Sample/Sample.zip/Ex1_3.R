   Value= c(101.2,100.3,99.8,99.8,99.9,100.1,99.9,100.3,99.9,100.1)
 plot(Value)
abline(h=mean(Value))